let html = document.querySelector(".html textarea"),
css = document.querySelector(".css textarea"),
javascript = document.querySelector(".javascript textarea"),
switchThemeBtn = document.querySelector(".switch-theme"),
body = document.body,
time = document.querySelector(".time span");

function run() {
    let htmlCode = document.querySelector(".html #html").value,
    cssCode = document.querySelector(".css #css").value,
    javascriptCode = document.querySelector(".javascript #js").value,
    iframe = document.querySelector(".code-output");
    iframe.contentDocument.body.innerHTML = `${htmlCode} <style>${cssCode}</style>`;
    iframe.contentWindow.eval(javascriptCode);
}

let elems = [ html, css, javascript ];
elems.forEach(elem=>{
    elem.addEventListener("keydown", run);
});

switchThemeBtn.addEventListener("click", function(){
    this.classList.toggle("active");
    body.classList.toggle("dark-mode");
});


function getTime() { 
    let dt = new Date(), hours = dt.getHours(), mins = dt.getMinutes(), seconds = dt.getSeconds(), dayNight;
    hours = (hours < 10) ? `0${hours}` : `${hours}`;
    dayNight = (hours > 12) ? "PM" : "AM";
    mins = (mins < 10) ? `0${mins}` : `${mins}`;
    seconds = (seconds < 10) ? `0${seconds}` : `${seconds}`;
    time.textContent = `${hours} : ${mins} : ${seconds} ${dayNight}`;
}
setInterval(()=>{
    getTime();
}, 1000);
